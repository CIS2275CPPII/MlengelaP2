//File: DateDriver.cpp

#include <iostream>
#include "Date.h"

using namespace std;

int main()
{
	cout<<"The demo program for our Date class. ";
	
	//Make one Date object using the default constructor.
	//It contains our default data--which is today's date.
//	Date myDefDate;
	
	//Make another Date object and pass in our own data.
	//Date myOwnDate


	//Now ask each Date object for its formatted string.
	//

	cout << "\nThe Default Date is:\n";
//	cout << /<< endl;

	cout << "My Own Date is:\n";
//	cout << / << endl;
	
	return 0;
}